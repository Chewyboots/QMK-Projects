This is a 16 switch keypad designed by 1upkeyboards.com and built by Chewyboots. This is Chewyboot's first QMK keypad project and will be a living project as the layers and overall use for this keypad is figured out. This keypad will have multiple layers from a standard numpad to macros to launch Windows Programs.
PCB Kit: https://www.1upkeyboards.com/shop/keyboard-kits/macro-pads/super-16-macro-pad/
Key Switches: https://novelkeys.xyz/collections/switches/products/novelkeys-x-kailh-pro-heavys?variant=3747977297960
Keycaps: http://www.maxkeyboard.com/row-4-size-1x1-cherry-mx-keycap-r4-1x1.html